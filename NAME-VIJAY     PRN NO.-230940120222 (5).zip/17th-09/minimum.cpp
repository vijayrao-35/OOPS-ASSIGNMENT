#include<iostream>
using namespace std;
int findmin(int arr[],int n)
{
    int min=arr[0];
    for(int i=1;i<n;i++)
    {
        if(min>arr[i])
        min=arr[i];
    }
    return min;
}

int main()
{
   int arr[100],n,min;
   do
   {
   cout<<"enter size of array :-(<=100) ";
   cin>>n;
    /* code */
   } while (n<=0||n>100);
cout<<"\nenter values :-";
   for(int i=0;i<n;i++)
   {
      cin>>arr[i];
   }

min=findmin(arr,n);

cout<<"\nmin is :- "<<min;

    return 0;
}