#include<iostream>
using namespace std;
int find2ndmax(int arr[],int n)
{
    int max=arr[0];int second_max=arr[1];
    for(int i=1;i<n;i++)
    {
        if(max<arr[i])
        {
            second_max=max;
                    max=arr[i];

        }
    }
    return second_max;
}

int main()
{
   int arr[100],n,second_max;
   do
   {
   cout<<"enter size of array :-(1<size<=100) ";
   cin>>n;
    /* code */
   } while (n<=1||n>100);
cout<<"\nenter values :-";
   for(int i=0;i<n;i++)
   {
      cin>>arr[i];
   }

second_max=find2ndmax(arr,n);

cout<<"\nsecond max is :- "<<second_max;

    return 0;
}