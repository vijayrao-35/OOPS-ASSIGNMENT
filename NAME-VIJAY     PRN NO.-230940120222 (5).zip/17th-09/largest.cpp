#include<iostream>
using namespace std;
int findmax(int arr[],int n)
{
    int max=arr[0];
    for(int i=1;i<n;i++)
    {
        if(max<arr[i])
        max=arr[i];
    }
    return max;
}

int main()
{
   int arr[100],n,max;
   do
   {
   cout<<"enter size of array :-(<=100) ";
   cin>>n;
    /* code */
   } while (n<=0||n>100);
cout<<"\nenter values :-";
   for(int i=0;i<n;i++)
   {
      cin>>arr[i];
   }

max=findmax(arr,n);

cout<<"\nmax is :- "<<max;

    return 0;
}