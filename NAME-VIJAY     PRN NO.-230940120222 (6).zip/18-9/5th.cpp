#include <iostream>
using namespace std;

void tolower(char str[])
{   int i=0;
    while(str[i]!='\0')
    {
        if(str[i]>=65 && str[i]<=90)
         str[i]+=32;
        i++;
    }
    return;
}
int main()
{
    char str1[100];

    cout << "\n enter a 1st string to convert in lower case :-";
    scanf("%s", str1);

    tolower(str1);

    cout<<"\n after operation string is :- "<<str1;
    
    return 0;
}