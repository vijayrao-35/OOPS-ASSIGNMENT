#include <iostream>
using namespace std;

bool compare(char s1[], char s2[])
{
    int i = 0; 
    while (s1[i]!='\0'&& s2[i]!='\0')
    {

        if(s1[i]!=s2[i])return false;
        i++;
    }

    
     if(s1[i]=='\0' && s2[i]=='\0') return true;
  
    return false;
}
int main()
{   cout<<"\n program to compare tow string :- ";
    char str1[100], str2[100];

    cout << "\n enter a 1st string :-";
    scanf("%s", str1);

     cout << "\n enter a 2nd string :-";
    scanf("%s", str2);
    

    bool flag=compare(str2, str1);
    if(flag)
    cout<<"entered string are equal ";
    else
    cout<<"entered string are not equal ";

    return 0;
}