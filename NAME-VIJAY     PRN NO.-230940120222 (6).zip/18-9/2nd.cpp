#include <iostream>
using namespace std;

void strcpy(char det[], char src[])
{
    int i = 0;
    while (src[i] != '\0')
    {

        det[i] = src[i];

        i++;
    }
    det[i]='\0';

    return;
}
int main()
{   cout<<"\n program to copy 2 string :- ";
    char str1[100], str2[100];

    cout << "\n enter a 1st string :-";
    scanf("%s", str1);
     cout << "\n enter a 2nd string :-";
    scanf("%s", str2);

    strcpy(str2, str1);

    cout<<"\nafter copy 2nd string is :- ";

    cout<<str2<<endl;

    return 0;
}