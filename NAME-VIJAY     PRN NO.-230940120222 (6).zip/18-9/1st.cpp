#include<iostream>
using namespace std;
int strlen(char str[])
{
    int count=0;
    while(*str!='\0')
    {
        str++;
        count++;
    }
    return count;
}

int main()
{   cout<<"\n program for calculate string length ";
    char str[100]; int str_len;
    cout<<"enter a string :- ";
    scanf("%s",str);

    str_len=strlen(str);
    cout<<"\n final string length :-"<<str_len;

    return 0;

}