#include <iostream>
using namespace std;

void toupper(char str[])
{   int i=0;
    while(str[i]!='\0')
    {
        if(str[i]>=97 && str[i]<=122)
         str[i]-=32;
        i++;
    }
    return;
}
int main()
{
    char str1[100];

    cout << "\n enter a 1st string to convert in upper case :-";
    scanf("%s", str1);

    toupper(str1);

    cout<<"\n after operation string is :- "<<str1;
    
    return 0;
}