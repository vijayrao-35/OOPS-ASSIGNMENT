#include<iostream>
using namespace std;
void swap(int &a,int &b)
{
    a=a+b;
    b=a-b;
    a=a-b;
}

void swap(double &a,double &b)
{
        a=a+b;
        b=a-b;
        a=a-b;
}

void swap(char &a,char &b)
{
        a=a+b;
        b=a-b;
        a=a-b;
}
int main()
{
    int int1,int2;
    double double1,double2;
    char char1,char2;

    cout<<" enter 2 intezer :- ";
    cin>>int1>>int2;
    cout<<" enter 2 double :- ";
    cin>>double1>>double2;
    cout<<" enter 2 char :- ";
    cin>>char1>>char2;

    swap(int1,int2);
    swap(double1,double2);
    swap(char1,char2);

    cout<<"\nAfter swap result is :- "<<"\n int 1 and 2 :- "<<int1<<"  "<<int2;
    cout<<"\nAfter swap result is :- "<<"\n double 1 and 2 :- "<<double1<<"  "<<double2;
    cout<<"\nAfter swap result is :- "<<"\n char 1 and 2 :- "<<char1<<"  "<<char2;

    return 0;
}